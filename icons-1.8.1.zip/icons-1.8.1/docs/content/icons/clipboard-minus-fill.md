---
title: Clipboard minus fill
categories:
  - Real world
tags:
  - copy
  - paste
---
