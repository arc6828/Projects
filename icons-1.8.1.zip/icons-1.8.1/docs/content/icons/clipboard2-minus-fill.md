---
title: Clipboard2 minus fill
categories:
  - Real world
tags:
  - copy
  - paste
---
